def vitCalc(t):
    start = 0
    s, o = getTestCase(testSentences[t])
    testCase = s
    prediction = viterbiAlgo(testCase, rows, columns, word_index, index_state, lstm, lsem)
    f.write('i: ' + str(i) + '\n')
    f.write(' '.join(prediction) + '\n')
    f.write(' '.join(o) + '\n')
    f.write('\n')
    print(t)
