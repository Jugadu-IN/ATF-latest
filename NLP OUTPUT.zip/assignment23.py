#!/usr/bin/env python
# coding: utf-8

# In[14]:


#import nltk
#import pandas as pd
import numpy as np
#import matplotlib.pyplot as plt
#from copy import deepcopy


# In[2]:


with open('Brown_train.txt', 'r') as f:
    data = f.read()


# In[3]:


def getSentences(corpus):
    sentences = corpus.split('\n')
    return sentences

sentences = getSentences(data)


# In[4]:


size3 = len(sentences)//3
size = len(sentences)
X_1 = sentences[0:2*size3]
Y_1 = sentences[2*size3:]

X_2 = sentences[0:size3] + sentences[2*size3:]
Y_2 = sentences[size3+1: 2*size3]

X_3 = sentences[size3:]
Y_3 = sentences[:size3]

ValidationSet = [[X_1,Y_1], [X_2, Y_2], [X_3, Y_3]]


# In[165]:





# In[5]:


def generateNewSentence(sentence):
    parts = sentence.split(' ')
    tempSentence = [['<START>', 'STRT']]
    for part in parts:
        try:
            word, tag = part.split('_')
            word = word.lower()
            tempSentence.append([word, tag])
        except:
            pass
            #print(part)
    tempSentence.append(['<END>', 'END'])
    return tempSentence

def getWordsAndStates(sentence, word_states, states_words):
    for part in sentence:
        try:
            word, tag = part
            word_states[word] = word_states.get(word, dict())
            states_words[tag] = states_words.get(tag, dict())
            word_states[word][tag] = word_states[word].get(tag, 0) + 1
            states_words[tag][word] = states_words[tag].get(word, 0) + 1
        except:
            pass
            #print(part)
    word_states['<UNK>'] = dict()


# In[6]:


def getNewSentences(sentences):
    newSentences = []
    for s in sentences:
        newSentences.append(generateNewSentence(s))
    return newSentences


# In[7]:


# SETUP
state_index  = {}
index_state  = {}
word_index   = {}
index_word   = {}
states_words = {}
word_states  = {}

def MatrixSetup(newSentences, word_states, states_words):
    #newSentences = getNewSentences(sentences)
    for s in newSentences:
        getWordsAndStates(s, word_states, states_words)
        
def indexFind(word_states, states_words):
    state_index  = {}
    index_state  = {}
    word_index   = {}
    index_word   = {}
    index = 0
    for word in word_states:
        word_index[word] = index
        index_word[index] = word
        index += 1
    index = 0
    for state in states_words:
        state_index[state] = index
        index_state[index] = state
        index += 1
    return word_index, index_word, state_index, index_state
    


# In[15]:


#state_index  = {}
#index_state  = {}
#word_index   = {}
#index_word   = {}
#states_words = {}
#word_states  = {}
##newSentences = getNewSentences(sentences)
##MatrixSetup(newSentences)
#indexFind()


# In[21]:


#columns = []
#rows = []
#for i in range(len(word_index)):
#    columns.append(index_word[i])
#for i in range(len(state_index)):
#    rows.append(index_state[i])


# In[8]:


def getEmissionMatrix(index_word, index_state, word_states):
    m = len(index_word)
    n = len(index_state)
    emission = []
    #print(word_states)
    for j in range(n):
        arr = []
        for i in range(m):
            arr.append(word_states[index_word[i]].get(index_state[j], 0))
        emission.append(arr)
    return np.array(emission)

def smoothMatrix(matrix):
    m, n = matrix.shape
    sums = np.sum(matrix, axis=1).reshape(m, 1)
    sums += m
    answer = (matrix+1)/(sums.reshape(m, 1))
    return answer

def getTransitionMatrix(index_state, state_index, newSentences):
    transitionMatrix = np.zeros((len(index_state), len(index_state)))
    for sentence in newSentences:
        l = len(sentence)
        for j in range(1, l):
                transitionMatrix[state_index[sentence[j-1][1]]][state_index[sentence[j][1]]] += 1
    return transitionMatrix


# In[62]:


#em = getEmissionMatrix()
#tm = getTransitionMatrix()
#sem = smoothMatrix(em)
##stm = smoothMatrix(tm)
#lsem = np.log2(sem)
#lstm = np.log2(stm)


# In[193]:


#tmdf = pd.DataFrame(lstm, columns=rows, index=rows)
#emdf = pd.DataFrame(lsem, columns=columns, index=rows)


# In[64]:





# In[9]:


#output = []
def getTestCase(sentence):
    s = []
    output = []
    for i in sentence:
        #print(i)
        s.append(i[0])
        output.append(i[1])
    return s, output

#test = getTes


# In[10]:


def viterbiAlgo(test, rows, columns, word_index, index_state, lstm, lsem):
    numRows = len(rows)
    numCol = len(columns)
    viterbiMatrix = np.zeros((numRows, len(test)))
    backProp = np.zeros((numRows, len(test)))
    viterbiMatrix[0][0] = 0
    backProp[0][0] = 0
    for i in range(1, numRows):
        viterbiMatrix[i][0] = -1
    for i in range(1, len(test)):
        currWord = test[i]
        ind = word_index.get(currWord, word_index.get('<UNK>')) 
        for j in range(numRows):
            tempTag = index_state[j]
            viterbiMatrix[j][i] = '-inf'
            for k in range(numRows):
                tempScore = viterbiMatrix[k][i-1] + lstm[k][j] + lsem[j][ind]
                if (tempScore > viterbiMatrix[j][i]):
                    viterbiMatrix[j][i] = tempScore
                    backProp[j][i] = k
    argmax = np.argmax(viterbiMatrix[:, -1])
    backIndex = backProp[argmax, -1]
    ans = []
    for j in range(len(test)-1, 0, -1):
        ans.append(index_state[backIndex])
        backIndex = backProp[int(backIndex), j]
    ans.append('STRT')
    ans = ans[::-1]
    ans[-1] = 'END'
    return ans
        


# In[11]:


#word_index['<UNK>']


# In[12]:


#argmax = np.argmax(viterbiMatrix[:, -1])
#backIndex = backProp[argmax, -1]
#ans = []
##for j in range(len(test)-1, 0, -1):
#    ans.append(index_state[backIndex])
#    backIndex = backProp[int(backIndex), j]
#ans = ans[::-1]

#for i in range(1, len(output)):
#    print(ans[i-1], output[i])


# In[13]:


f = open('test2', 'a+')

size = 3000
index = 2
state_index  = {}
index_state  = {}
word_index   = {}
index_word   = {}
states_words = {}
word_states  = {}
inputSets = ValidationSet[index]
train = inputSets[0]
test = inputSets[1]
newSentences = getNewSentences(train)
testSentences = getNewSentences(test)
#MatrixSetup(newSentences, word_states, states_words)
for newSentence in newSentences:
    getWordsAndStates(newSentence, word_states, states_words)
word_index, index_word, state_index, index_state = indexFind(word_states, states_words)
columns = []
rows = []
#print(word_states)
for i in range(len(word_index)):
    columns.append(index_word[i])
for i in range(len(state_index)):
    rows.append(index_state[i])
em = getEmissionMatrix(index_word, index_state, word_states)
tm = getTransitionMatrix(index_state, state_index, newSentences)
sem = smoothMatrix(em)
stm = smoothMatrix(tm)
lsem = np.log2(sem)
lstm = np.log2(stm)
testCases = []
outputCases = []


# In[34]:





# In[16]:


def vitCalc(t):
    start = 0
    s, o = getTestCase(testSentences[t])
    testCase = s
    prediction = viterbiAlgo(testCase, rows, columns, word_index, index_state, lstm, lsem)
    #f.write('i: ' + str(i) + '\n')
    #f.write(' '.join(prediction) + '\n')
    #f.write(' '.join(o) + '\n')
    #f.write('\n')
    print(t)
    return [t, prediction, o]


# In[ ]:


f = open('test0', 'a+')
#for i in range(115, 130):   
#    vitCalc(i)
#f.close()


# In[25]:


#f.close()


# In[15]:





# In[241]:





# In[242]:





# In[ ]:




